//
//  Created by Robert Petras
//  Credo Academy ♥ Design and Code
//  https://credo.academy 
//

import Foundation

let pagesData: [Page] = [
  Page(id: 1, imageName: "magazine-front-cover"),
  Page(id: 2, imageName: "magazine-back-cover")
]
